public class Paint{
	public static void main(String s[]){
		PaintDemo pd=new PaintDemo();
		pd.setVisible(true);
	}
}