import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.event.*;
class PaintDemo extends Frame implements ActionListener{
	private int x=120;
	private int y=170;
	public PaintDemo(){
		super("Oval Moving");
		Button b1=new Button("Right");
		Button b2=new Button("Left");
		Button b3=new Button("Up");
		Button b4=new Button("Down");
		Button b5=new Button("Exit");
		
		add(b1);add(b2);
		add(b3);add(b4);add(b5);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		
		setLayout(new FlowLayout());
		setSize(500,400);
		setLocation(800,200);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		String s=ae.getActionCommand();
		if(s.equals("Exit")){
			System.exit(0);
		}	
		
		if(s.equals("Right")){
			x=x+5;
			repaint();
		}	
		
		if(s.equals("Left")){
			x=x-5;
			repaint();
			
		}	
		
		if(s.equals("Up")){
			y=y-5;
			repaint();
		}	
		
		if(s.equals("Down")){
			y=y+5;
			repaint() ;
		}	

			
	}
	public void paint(Graphics g){
		g.setColor(new Color(0,106,78));
		g.fillRect(25,150,300,150);
		g.setColor(new Color(244,42,65));
		g.fillOval(x,y,100,100);
	}
}
