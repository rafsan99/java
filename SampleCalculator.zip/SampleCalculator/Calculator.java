import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
class Calculator extends Frame implements ActionListener{
	private TextField tf;
	private TextField tf2;
	private TextField tf3;
	private Label l3=new Label("Result = ");
	private Label l4=new Label();
	private int res = 0;
	private int mr = 0;
	public Calculator(){
		super("Java Calculator");
		
		Label l=new Label("Value 1");
		Label l2=new Label("Value 2");
		
		tf=new TextField(28);
		tf2=new TextField(28);
		
		
		Button b=new Button("+");
		Button b2=new Button("-");
	    Button b3=new Button("/");
		Button b4=new Button("*");
		Button b5=new Button("CLR");
		Button b6=new Button("M+");
		Button b7=new Button("MR");
		Button b8=new Button("%");
		
		add(l);add(tf);
		add(l2);add(tf2);
		add(b);add(b2);
		add(b3);add(b4);
		add(b5);add(b6);
		add(b7);add(b8);
		add(l3);add(l4);
		
		b.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);
		b7.addActionListener(this);
		b8.addActionListener(this);
		
		setLayout(new FlowLayout());
		setSize(265,400);
		setLocation(500,200);
		setVisible(true);
		
		addWindowListener(new WindowAdapter(){
			@Override 
			public void windowClosing(WindowEvent e)
			{System.exit(0);}
		});
	}
	public void actionPerformed(ActionEvent ae){
		String s=ae.getActionCommand();
		
	if(s.equals("+"))
		{
			
			int n1 = Integer.parseInt(tf.getText());
			int n2 = Integer.parseInt(tf2.getText());
		    res = n1+n2;
			l4.setText(String.valueOf(res));
		}
	if(s.equals("-"))
		{
			
			int n1 = Integer.parseInt(tf.getText());
			int n2 = Integer.parseInt(tf2.getText());
			res = n1-n2;
			l4.setText(String.valueOf(res));
		}
	if(s.equals("/"))
		{
			
			int n1 = Integer.parseInt(tf.getText());
			int n2 = Integer.parseInt(tf2.getText());
			res = n1/n2;
			l4.setText(String.valueOf(res));
		}
	if(s.equals("*"))
		{
			
			int n1 = Integer.parseInt(tf.getText());
			int n2 = Integer.parseInt(tf2.getText());
			res = n1*n2;
			l4.setText(String.valueOf(res));
		}
	if(s.equals("CLR"))
		{
			  res = 0;
			  l4.setText(String.valueOf(res));
		}
    if(s.equals("%"))
		{
			int n1 = Integer.parseInt(tf.getText());
			int n2 = Integer.parseInt(tf2.getText());
			res = n1%n2;
			l4.setText(String.valueOf(res));
		}
	if(s.equals("M+"))
		{
			mr = res;
		}
	if(s.equals("MR"))
		{
			l4.setText(String.valueOf(mr));
		}
		
	}
}


